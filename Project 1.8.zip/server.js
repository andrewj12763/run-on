var bodyParser = require('body-parser');
var express = require('express');
var exphbs = require('express-handlebars');
var path = require('path');

var app = express();

// Body Parser Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Load Routes
var index = require("./controllers/min-control");

// Routes
app.use('/', index);
app.use(express.static('app'));
// Set Handlebars.
app.engine(".hbs", exphbs({ defaultLayout: "main", extname: '.hbs' }));
app.set("view engine", ".hbs");


const PORT = process.env.PORT || 3800

// Start listening on PORT
app.listen(PORT, function() {
  console.log('Run-on app is listening on PORT: ' + PORT);
});