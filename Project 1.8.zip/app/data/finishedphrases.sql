SELECT * FROM runon_db.finishedphrases;

INSERT INTO finishedphrases (finalphrase)
VALUES ("I found sandpaper in a hopless place");
INSERT INTO finishedphrases (finalphrase)
VALUES ("What I like best about billy is he died");