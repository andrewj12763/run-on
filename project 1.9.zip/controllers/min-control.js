const express = require('express');
const router = express.Router();
var db = require("../models")

// This is where we need to add the request code -----------------------
module.exports = function(sequelize, DataTypes) {
  var Post = sequelize.define("Post", {
    title: {
      type: DataTypes.STRING,
      allowNull: false,
      validate: {
        len: [1]
      }
    },
    body: {
      type: DataTypes.TEXT,
      allowNull: false,
      validate: {
        len: [1]
      }
    },
    category: {
      type: DataTypes.STRING,
      defaultValue: "Personal"
    }
  });
  return Post;
};

// DO NOT CHANGE ANYTHING AFTER THIS LINE------------------------------------

router.get('/', (req, res) => {
  res.render('home');
});

router.get('/page2', (req, res) => {
  res.render('page2');
});



router.get('/page3', (req, res) => {
  res.render('page3');
});

module.exports = router