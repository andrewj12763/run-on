var bodyParser = require('body-parser');
var express = require('express');
var exphbs = require('express-handlebars');
var path = require('path');
var mysql = require("mysql");

var app = express();

// Body Parser Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Load Routes
var index = require("./controllers/min-control");

// Routes
app.use('/', index);
app.use(express.static('app'));
// Set Handlebars.
app.engine(".hbs", exphbs({ defaultLayout: "main", extname: '.hbs' }));
app.set("view engine", ".hbs");

var connection = mysql.createConnection({
	host: "localhost",
  user: "root",
  password: "yolo",
  database: "runon_db"
});

var PORT = 5000;

// Start our server so that it can begin listening to client requests.
app.listen(PORT, function() {
  // Log (server-side) when our server has started
	console.log("Server listening on: http://localhost:" + PORT);
});

// var gamenames;

// function gamenames() {
//   connection.query("SELECT wish FROM runon_db.activegames;", function(err, res) {
//     if (err) throw err;

//     // Log all results of the SELECT statement
// 		// console.log(res);
// 		gamenames = res;
// 		connection.end();
//   });
// }

// gamenames();